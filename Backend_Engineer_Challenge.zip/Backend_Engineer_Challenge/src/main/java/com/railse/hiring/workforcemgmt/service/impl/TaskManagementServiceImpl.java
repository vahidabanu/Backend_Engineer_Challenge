package com.railse.hiring.workforcemgmt.service.impl;

import com.railse.hiring.workforcemgmt.common.exception.ResourceNotFoundException;
import com.railse.hiring.workforcemgmt.dto.*;
import com.railse.hiring.workforcemgmt.mapper.ITaskManagementMapper;
import com.railse.hiring.workforcemgmt.model.TaskActivity;
import com.railse.hiring.workforcemgmt.model.TaskManagement;
import com.railse.hiring.workforcemgmt.model.enums.Priority;
import com.railse.hiring.workforcemgmt.model.enums.Task;
import com.railse.hiring.workforcemgmt.model.enums.TaskStatus;
import com.railse.hiring.workforcemgmt.repository.TaskActivityRepository;
import com.railse.hiring.workforcemgmt.repository.TaskRepository;
import com.railse.hiring.workforcemgmt.service.TaskManagementService;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TaskManagementServiceImpl implements TaskManagementService {

   private final TaskRepository taskRepository;
   private final TaskActivityRepository activityRepository;
   private final ITaskManagementMapper taskMapper;

   public TaskManagementServiceImpl(TaskRepository taskRepository, 
                                 TaskActivityRepository activityRepository,
                                 ITaskManagementMapper taskMapper) {
       this.taskRepository = taskRepository;
       this.activityRepository = activityRepository;
       this.taskMapper = taskMapper;
   }

   @Override
   public TaskManagementDto findTaskById(Long id) {
       TaskManagement task = taskRepository.findById(id)
               .orElseThrow(() -> new ResourceNotFoundException("Task not found with id: " + id));
       
       TaskManagementDto dto = taskMapper.modelToDto(task);
       // Add activity history
       List<TaskActivity> activities = activityRepository.findByTaskIdOrderByTimestampDesc(id);
       dto.setActivities(activities);
       
       return dto;
   }

   @Override
   public List<TaskManagementDto> createTasks(TaskCreateRequest createRequest) {
       List<TaskManagement> createdTasks = new ArrayList<>();
       for (TaskCreateRequest.RequestItem item : createRequest.getRequests()) {
           TaskManagement newTask = new TaskManagement();
           newTask.setReferenceId(item.getReferenceId());
           newTask.setReferenceType(item.getReferenceType());
           newTask.setTask(item.getTask());
           newTask.setAssigneeId(item.getAssigneeId());
           newTask.setPriority(item.getPriority());
           newTask.setTaskDeadlineTime(item.getTaskDeadlineTime());
           newTask.setStatus(TaskStatus.ASSIGNED);
           newTask.setDescription("New task created.");
           
           TaskManagement savedTask = taskRepository.save(newTask);
           
           // Log activity
           TaskActivity activity = new TaskActivity();
           activity.setTaskId(savedTask.getId());
           activity.setActivityType("CREATED");
           activity.setDescription("Task created");
           activity.setPerformedBy("System");
           activityRepository.save(activity);
           
           createdTasks.add(savedTask);
       }
       return taskMapper.modelListToDtoList(createdTasks);
   }

   @Override
   public List<TaskManagementDto> updateTasks(UpdateTaskRequest updateRequest) {
       List<TaskManagement> updatedTasks = new ArrayList<>();
       for (UpdateTaskRequest.RequestItem item : updateRequest.getRequests()) {
           TaskManagement task = taskRepository.findById(item.getTaskId())
                   .orElseThrow(() -> new ResourceNotFoundException("Task not found with id: " + item.getTaskId()));

           if (item.getTaskStatus() != null) {
               TaskStatus oldStatus = task.getStatus();
               task.setStatus(item.getTaskStatus());
               
               // Log status change activity
               TaskActivity activity = new TaskActivity();
               activity.setTaskId(task.getId());
               activity.setActivityType("STATUS_CHANGED");
               activity.setDescription("Status changed from " + oldStatus + " to " + item.getTaskStatus());
               activity.setPerformedBy("System");
               activityRepository.save(activity);
           }
           
           if (item.getDescription() != null) {
               task.setDescription(item.getDescription());
           }
           
           updatedTasks.add(taskRepository.save(task));
       }
       return taskMapper.modelListToDtoList(updatedTasks);
   }

   @Override
   public String assignByReference(AssignByReferenceRequest request) {
       List<Task> applicableTasks = Task.getTasksByReferenceType(request.getReferenceType());
       List<TaskManagement> existingTasks = taskRepository.findByReferenceIdAndReferenceType(request.getReferenceId(), request.getReferenceType());

       for (Task taskType : applicableTasks) {
           List<TaskManagement> tasksOfType = existingTasks.stream()
                   .filter(t -> t.getTask() == taskType && t.getStatus() != TaskStatus.COMPLETED)
                   .collect(Collectors.toList());

           if (!tasksOfType.isEmpty()) {
               // BUG #1 FIX: Cancel all existing tasks and assign only one to the new assignee
               for (TaskManagement taskToUpdate : tasksOfType) {
                   if (taskToUpdate.getAssigneeId().equals(request.getAssigneeId())) {
                       // Skip if already assigned to the same person
                       continue;
                   }
                   
                   // Cancel the old task
                   taskToUpdate.setStatus(TaskStatus.CANCELLED);
                   taskRepository.save(taskToUpdate);
                   
                   // Log cancellation activity
                   TaskActivity activity = new TaskActivity();
                   activity.setTaskId(taskToUpdate.getId());
                   activity.setActivityType("STATUS_CHANGED");
                   activity.setDescription("Task cancelled due to reassignment");
                   activity.setPerformedBy("System");
                   activityRepository.save(activity);
               }
               
               // Create new task for the new assignee
               TaskManagement newTask = new TaskManagement();
               newTask.setReferenceId(request.getReferenceId());
               newTask.setReferenceType(request.getReferenceType());
               newTask.setTask(taskType);
               newTask.setAssigneeId(request.getAssigneeId());
               newTask.setStatus(TaskStatus.ASSIGNED);
               newTask.setPriority(Priority.MEDIUM); // Default priority
               newTask.setDescription("Task reassigned to new assignee.");
               newTask.setTaskDeadlineTime(System.currentTimeMillis() + 86400000); // 1 day from now
               
               TaskManagement savedTask = taskRepository.save(newTask);
               
               // Log assignment activity
               TaskActivity activity = new TaskActivity();
               activity.setTaskId(savedTask.getId());
               activity.setActivityType("ASSIGNEE_CHANGED");
               activity.setDescription("Task assigned to assignee " + request.getAssigneeId());
               activity.setPerformedBy("System");
               activityRepository.save(activity);
           } else {
               // Create a new task if none exist
               TaskManagement newTask = new TaskManagement();
               newTask.setReferenceId(request.getReferenceId());
               newTask.setReferenceType(request.getReferenceType());
               newTask.setTask(taskType);
               newTask.setAssigneeId(request.getAssigneeId());
               newTask.setStatus(TaskStatus.ASSIGNED);
               newTask.setPriority(Priority.MEDIUM); // Default priority
               newTask.setDescription("New task created.");
               newTask.setTaskDeadlineTime(System.currentTimeMillis() + 86400000); // 1 day from now
               
               TaskManagement savedTask = taskRepository.save(newTask);
               
               // Log creation activity
               TaskActivity activity = new TaskActivity();
               activity.setTaskId(savedTask.getId());
               activity.setActivityType("CREATED");
               activity.setDescription("Task created");
               activity.setPerformedBy("System");
               activityRepository.save(activity);
           }
       }
       return "Tasks assigned successfully for reference " + request.getReferenceId();
   }

   @Override
   public List<TaskManagementDto> fetchTasksByDate(TaskFetchByDateRequest request) {
       // BUG #2 FIX: Filter out CANCELLED tasks
       List<TaskManagement> tasks = taskRepository.findByAssigneeIdInAndStatusNotIn(
           request.getAssigneeIds(), 
           Arrays.asList(TaskStatus.CANCELLED)
       );

       // Feature 1: Smart Daily Task View - Enhanced date filtering logic
       List<TaskManagement> filteredTasks = tasks.stream()
               .filter(task -> {
                   long taskStartTime = task.getTaskDeadlineTime();
                   long startDate = request.getStartDate();
                   long endDate = request.getEndDate();
                   
                   // Return tasks that:
                   // 1. Started within the date range, OR
                   // 2. Started before the range but are still active (not completed)
                   return (taskStartTime >= startDate && taskStartTime <= endDate) ||
                          (taskStartTime < startDate && task.getStatus() == TaskStatus.ASSIGNED);
               })
               .collect(Collectors.toList());

       return taskMapper.modelListToDtoList(filteredTasks);
   }

   @Override
   public TaskManagementDto updateTaskPriority(UpdatePriorityRequest request) {
       TaskManagement task = taskRepository.findById(request.getTaskId())
               .orElseThrow(() -> new ResourceNotFoundException("Task not found with id: " + request.getTaskId()));

       Priority oldPriority = task.getPriority();
       task.setPriority(request.getPriority());
       TaskManagement updatedTask = taskRepository.save(task);
       
       // Log priority change activity
       TaskActivity activity = new TaskActivity();
       activity.setTaskId(task.getId());
       activity.setActivityType("PRIORITY_CHANGED");
       activity.setDescription("Priority changed from " + oldPriority + " to " + request.getPriority());
       activity.setPerformedBy("System");
       activityRepository.save(activity);
       
       return taskMapper.modelToDto(updatedTask);
   }

   @Override
   public List<TaskManagementDto> findTasksByPriority(Priority priority) {
       List<TaskManagement> tasks = taskRepository.findByPriority(priority);
       return taskMapper.modelListToDtoList(tasks);
   }

   @Override
   public TaskManagementDto addComment(AddCommentRequest request) {
       TaskManagement task = taskRepository.findById(request.getTaskId())
               .orElseThrow(() -> new ResourceNotFoundException("Task not found with id: " + request.getTaskId()));

       // Log comment activity
       TaskActivity activity = new TaskActivity();
       activity.setTaskId(task.getId());
       activity.setActivityType("COMMENT_ADDED");
       activity.setDescription("Comment added: " + request.getComment());
       activity.setPerformedBy(request.getPerformedBy());
       activity.setComment(request.getComment());
       activityRepository.save(activity);
       
       return taskMapper.modelToDto(task);
   }
} 
package com.railse.hiring.workforcemgmt.repository;

import com.railse.hiring.workforcemgmt.model.TaskActivity;

import java.util.List;
import java.util.Optional;

public interface TaskActivityRepository {
   Optional<TaskActivity> findById(Long id);
   TaskActivity save(TaskActivity activity);
   List<TaskActivity> findByTaskIdOrderByTimestampDesc(Long taskId);
   List<TaskActivity> findByTaskId(Long taskId);
} 
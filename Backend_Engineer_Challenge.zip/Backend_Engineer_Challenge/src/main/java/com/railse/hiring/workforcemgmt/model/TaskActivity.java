package com.railse.hiring.workforcemgmt.model;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TaskActivity {
    private Long id;
    private Long taskId;
    private String activityType; // CREATED, STATUS_CHANGED, PRIORITY_CHANGED, ASSIGNEE_CHANGED, COMMENT_ADDED
    private String description;
    private String performedBy; // User ID or name
    private LocalDateTime timestamp;
    private String comment; // For user comments
} 
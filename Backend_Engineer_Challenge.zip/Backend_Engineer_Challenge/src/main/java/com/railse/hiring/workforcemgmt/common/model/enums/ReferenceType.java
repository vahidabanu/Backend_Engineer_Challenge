package com.railse.hiring.workforcemgmt.common.model.enums;

public enum ReferenceType {
   ENTITY, // Represents a Customer/Transporter
   ORDER,
   ENQUIRY
} 